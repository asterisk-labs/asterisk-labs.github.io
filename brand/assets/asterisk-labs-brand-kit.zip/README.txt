asterisk labs — logo & brand kit

svg/     vectors, wordmark font embedded (use for print and anything that scales)
png/     rasters, transparent + solid-background versions
corners/ corner-frame overlays per format + copy-paste web snippet

naming
  mark-*             symbol only
  logo-horizontal-*  mark + wordmark side by side
  logo-stacked-*     mark above wordmark
  icon-* favicon-*   square app / browser icons
  avatar-*           square social profile images (indigo is default)
  *-color            full colour        *-black / *-white  monochrome
  *-dark1            white outline + white centre (default on dark)
  *-dark2            white mark, colour nodes (solid black only)
  *-on-white/-on-ink baked solid background

notes
  black-outline marks carry a white centre; monochrome marks are hollow.
  white is the primary ground, indigo the main alternative.
  social avatars use the dark #1 (white outline) treatment.
  nodes may be recoloured for a deliberate context; never gradient the mark.

full guidelines: https://asterisk.coop
